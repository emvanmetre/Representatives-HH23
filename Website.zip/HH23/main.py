from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/about-us")
def about():
    return render_template("about.html")


@app.route('/representative', methods=['GET', 'POST'])
def find_rep():
        text = request.form["text"]
        issue = request.form["selection"]
        return render_template("representative.html", rep=text, issue=issue)


if __name__ == "__main__":
    app.run()
