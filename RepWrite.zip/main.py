from flask import Flask, render_template, request
import pandas as pd
import cohere

app = Flask(__name__)

# enter api code from cohere
co = cohere.Client('<<cohere-api>>')


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/contact")
def contact():
    return render_template("contact.html", prompt="Zipcode", prompt_sel="Select a topic...")


@app.route("/about-us")
def about():
    return render_template("about.html")


@app.route('/representative', methods=['GET', 'POST'])
def find_rep():
    my_zip = request.form["zipcode"]
    issue = request.form["selection"]
    my_name = request.form["your-name"]
    issue_topics = ["reducing carbon emission.", "improved solid waste management and disposal.", "renewable energy.",
                    "air pollution.", "microplastics.",
                    "restricting carrying firearms at public universities.", "accessible healthcare.",
                    "habitat restoration.",
                    "limiting invasive species.", "water quality management."]
    if issue == "Select a topic...":
        return render_template("contact.html", prompt="Zipcode", prompt_sel="Please select a topic!")
    issue = int(issue)

    reps = pd.read_csv("~/PycharmProjects/HH23/static/va_zips.csv")
    my_rep = reps[reps["zipcode"] == int(my_zip)]
    my_rep = str(my_rep.iloc[0, 2])
    my_issue = issue_topics[issue]

    print(my_rep + " " + my_issue)

    # Cohere Email Generation
    response = co.generate(
        model='command-xlarge-nightly',
        prompt='Write an email to ' + my_rep + ' with a 1-2 sentence argument about why congress ' +
                                               'should pass a bill about ' +
               my_issue + " make the greeting start with dear representative " + my_rep,
        max_tokens=300,
        temperature=0.9,
        k=0,
        p=0.75,
        stop_sequences=[],
        return_likelihoods='NONE')
    # print('Prediction: {}'.format(response.generations[0].text))
    email = (format(response.generations[0].text))
    email += "\n \n Sincerely, your constituent " + my_name + " " + my_zip
    print(email)

    if len(my_rep) > 0:
        return render_template("representative.html", rep=my_rep, issue=my_issue, contact=my_rep, message=email)
    return render_template("contact.html", prompt="Please enter a valid Virginia zipcode.",
                           prompt_sel="Select a topic...")


if __name__ == "__main__":
    app.run()
